# Import necessary modules
from asyncio import run

import export as export
import flask
from flask import Flask, render_template, request
from flask import Flask, jsonify

# Initialize Flask app
app = Flask(__name__)

# Define routes
@app.route('/')

def home():
    # Render home page
    return render_template('home.html')

@app.route('/art')
#app.route('/api/art', methods=['GET'])
def get_art_info():
    # Add code to retrieve and format information about indian art forms and their history
    art_info = {
        "painting": {
            "history": "Painting in India dates back to the ancient times as evident from the cave paintings of Ajanta and Ellora.",
            "styles": ["Madhubani", "Mughal", "Rajput", "Bengal School", "Tantra", "Contemporary"]
        },
        "sculpture": {
            "history": "Sculpture in India has a rich history, with ancient traditions that have been passed down through generations.",
            "styles": ["Buddhist", "Hindu", "Jain", "Modern"]
        },
        "performing arts": {
            "history": "Performing arts in India have a long history and are deeply rooted in the culture of the country.",
            "styles": ["Classical dances", "Folk dances", "Theatre"]
        }
    }
    return jsonify(art_info)


@app.route('/talent')
def talent():
    # Render talent page
    # TODO: Add code to retrieve and display information about digital artworks and performances
    return render_template('talent.html')

@app.route('/events')
def events():
    # Render events page
    # TODO: Add code to retrieve and display information about upcoming events and shows
    return render_template('events.html')

@app.route('/tickets', methods=['GET', 'POST'])
def tickets():
    if request.method == 'POST':
        # Process ticket booking form data
        name = request.form['name']
        email = request.form['email']
        event = request.form['event']
        quantity = request.form['quantity']
        # TODO: Add code to process payment and confirm booking
        return render_template('confirmation.html', name=name, event=event, quantity=quantity)
    else:
        # Render ticket booking form
        return render_template('tickets.html')

# Run the app
if __name__ == '__main__':
    # Run the app on port 8080
    app.run(port=8080)

from flask import Flask,render_template, request

app = Flask(__name__)
art_forms = {
'painting': 'Painting is the practice of applying paint, pigment, color or other medium to a solid surface.',
'sculpture': 'Sculpture is the branch of the visual arts that operates in three dimensions.',
'photography': 'Photography is the art, application, and practice of creating durable images by recording light.',
'music': 'Music is an art form, and cultural activity, whose medium is sound.',
'dance': 'Dance is a performing art form consisting of sequences of movement, typically rhythmic and to music.',
'theater': 'Theater is a collaborative form of performing art that uses live performers, typically actors or actresses, to present the experience of a real or imagined event before a live audience in a specific place.',
}

digital_artworks = [
{
'title': 'The Starry Night',
'artist': 'Vincent van Gogh',
'image_url': 'https://www.vangoghgallery.com/img/starry_night_full.jpg',
'description': 'The Starry Night is an oil on canvas painting by Dutch Post-Impressionist painter Vincent van Gogh.',
'art_form': 'painting'
},
{
'title': 'The Thinker',
'artist': 'Auguste Rodin',
'image_url': 'https://www.musee-rodin.fr/sites/musee/files/visuels/thinker-modele_3_72dpi.jpg',
'description': 'The Thinker is a bronze sculpture by Auguste Rodin, usually placed on a stone pedestal.',
'art_form': 'sculpture'
},
{
'title': 'Moonrise, Hernandez, New Mexico',
'artist': 'Ansel Adams',
'image_url': 'https://www.anseladams.com/wp-content/uploads/2016/08/Moonrise-Hernandez.jpg',
'description': 'Moonrise, Hernandez, New Mexico is a black and white photograph by Ansel Adams.',
'art_form': 'photography'
},
{
'title': 'Clair de Lune',
'artist': 'Claude Debussy',
'audio_url': 'https://upload.wikimedia.org/wikipedia/commons/9/96/Clair_de_Lune_%28Debussy%29.oga',
'description': 'Clair de Lune is a musical composition by French composer Claude Debussy.',
'art_form': 'music'
},
{
'title': 'Swan Lake',
'artist': 'Pyotr Ilyich Tchaikovsky',
'video_url': 'https://www.youtube.com/watch?v=9cBtLHp01fI',
'description': 'Swan Lake is a ballet composed by Pyotr Ilyich Tchaikovsky.',
'art_form': 'dance'
},
{
'title': 'Hamlet',
'artist': 'William Shakespeare',
'text_url': 'https://www.gutenberg.org/files/1524/1524-h/1524-h.htm',
'description': 'Hamlet is a tragedy by William Shakespeare, believed to have been written between 1599 and 1601.',
'art_form':'dance'
}
]
