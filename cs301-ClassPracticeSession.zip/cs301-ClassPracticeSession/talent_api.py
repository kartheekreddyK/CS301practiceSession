from flask import Flask, jsonify

app = Flask(__name__)

# Sample data for talent functionality
talent_data = [
    {
        "id": 1,
        "name": "John Doe",
        "talent": "Painter",
        "description": "John is a talented painter who specializes in landscapes and portraits.",
        "contact": {
            "email": "johndoe@email.com",
            "phone": "555-555-5555"
        }
    },
    {
        "id": 2,
        "name": "Jane Smith",
        "talent": "Sculptor",
        "description": "Jane is a skilled sculptor who works primarily with bronze and stone.",
        "contact": {
            "email": "janesmith@email.com",
            "phone": "555-555-5555"
        }
    },
    # Add more talent data as needed
]

@app.route('/api/talent', methods=['GET'])
def get_talent():
    return jsonify(talent_data)

if __name__ == '__main__':
    app.run()
