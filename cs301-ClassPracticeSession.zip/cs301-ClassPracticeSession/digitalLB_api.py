from flask import Flask
app = Flask(__name__)
@app.route('/')
class Artwork:
    def __init__(self, title, artist, medium, year, description, image_url, video_url=None):
        self.title = title
        self.artist = artist
        self.medium = medium
        self.year = year
        self.description = description
        self.image_url = image_url
        self.video_url = video_url

class ArtForm:
    def __init__(self, name, description, history, artworks):
        self.name = name
        self.description = description
        self.history = history
        self.artworks = artworks

class DigitalLibrary:
    def __init__(self, art_forms):
        self.art_forms = art_forms

    def search_artwork(self, keyword):
        results = []
        for art_form in self.art_forms:
            for artwork in art_form.artworks:
                if keyword in artwork.title or keyword in artwork.description:
                    results.append(artwork)
        return results

# Define some artworks
artwork1 = Artwork("Starry Night", "Vincent van Gogh", "Oil on canvas", 1889, "A famous painting of a starry night", "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg/800px-Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg", "https://www.youtube.com/watch?v=J2MU6xGb0MU")
artwork2 = Artwork("The Persistence of Memory", "Salvador Dali", "Oil on canvas", 1931, "A famous painting of melting clocks", "https://upload.wikimedia.org/wikipedia/en/4/4c/The_Persistence_of_Memory.jpg", "https://www.youtube.com/watch?v=rmWfS6zZqCw")
artwork3 = Artwork("Swan Lake", "Pyotr Ilyich Tchaikovsky", "Ballet", 1877, "A classic ballet about a princess who is turned into a swan by an evil sorcerer", "https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Swan_Lake_at_Mariinsky_Theatre_2013.jpg/800px-Swan_Lake_at_Mariinsky_Theatre_2013.jpg", "https://www.youtube.com/watch?v=SJ9fZFPQvqY")

# Define some art forms
art_form1 = ArtForm("Painting", "Painting is the practice of applying paint, pigment, color or other medium to a solid surface.", "Painting has a long and rich history that spans thousands of years.", [artwork1, artwork2])
art_form2 = ArtForm("Ballet", "Ballet is a type of performance dance that originated in the Italian Renaissance courts of the 15th century and later developed into a concert dance form in France and Russia.", "Ballet has a rich history that spans several centuries.", [artwork3])

# Create a digital library
digital_library = DigitalLibrary([art_form1, art_form2])

# Search for artworks
results = digital_library.search_artwork("night")
for artwork in results:
    print(artwork.title)
