from flask import Flask, jsonify

app = Flask(__name__)

# Sample events data
events = [
    {
        'id': 1,
        'title': 'Art Exhibition',
        'date': '2022-04-15',
        'location': 'Museum of Modern Art',
        'description': 'A showcase of modern art from around the world.'
    },
    {
        'id': 2,
        'title': 'Classical Music Concert',
        'date': '2022-05-01',
        'location': 'Carnegie Hall',
        'description': 'A night of classical music performed by renowned artists.'
    },
    {
        'id': 3,
        'title': 'Film Festival',
        'date': '2022-06-20',
        'location': 'Lincoln Center',
        'description': 'A festival featuring the latest and greatest in independent film.'
    }
]

# API endpoint for retrieving all events
@app.route('/api/events', methods=['GET'])
def get_events():
    return jsonify({'events': events})

# API endpoint for retrieving a specific event by ID
@app.route('/api/events/<int:event_id>', methods=['GET'])
def get_event(event_id):
    event = next((e for e in events if e['id'] == event_id), None)
    if event:
        return jsonify({'event': event})
    else:
        return jsonify({'error': 'Event not found'}), 404

if __name__ == '__main__':
    app.run(debug=True)
